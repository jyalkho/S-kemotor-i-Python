def lesInnTekst(filnavn):
    try:
        # Åpner filen og leser innholdet
        with open(filnavn, 'r', encoding="utf-8") as file:
            innhold = file.readlines()  # Leser linje for linje
        return innhold
    except FileNotFoundError:
        print(f"Filen {filnavn} finnes ikke.")
        return []
    except Exception as e:
        print(f"Det oppstod en feil ved lesing av filen: {e}")
        return []

def printTekst(innhold):
    for linje in innhold:
        print(linje.strip())  # Fjerner ekstra linjeskift

def printOrd(innhold, søkeord):
    for linje in innhold:
        if søkeord.lower() in linje.lower():
            print(linje.strip())  # Skriver ut linjen hvis ordet finnes

def finnOrd(innhold, søkeord):
    for linje in innhold:
        if søkeord.lower() in linje.lower():
            return True  # Returnerer True hvis ordet finnes
    return False  # Returnerer False hvis ordet ikke finnes

def tellOrd(innhold, søkeord):
    count = 0
    for linje in innhold:
        count += linje.lower().count(søkeord.lower())  # Teller hvor mange ganger ordet finnes i linjen
    return count

# Funksjonen for å vise hele hovedmenyen
def visMeny():
    print("\nVelg en fil ved å taste et tall (1-3):")
    print("1. Tekstfil1.txt")
    print("2. Tekstfil2.txt")
    print("3. Tekstfil3.txt")
    print("4. Avslutt")

#Funksjon for å jobbee  på valgt fil
def utførHandlinger(filnavn):
    innhold = lesInnTekst(filnavn)
    if not innhold:
        print(f"Kan ikke åpne filen {filnavn}.")
        return
    
    while True:
        print("\nVelg en handling:")
        print("1. Søk etter et ord")
        print("2. Vis innholdet i filen")
        print("3. Tell antall ganger av et ord")
        print("4. Tilbake til hovedmenyen")
        valg = input("Skriv tallet for ønsket handling: ")

        if valg == "1":
            søkeord = input("Skriv ordet du vil søke etter: ")
            if finnOrd(innhold, søkeord):
                print(f"Ordet '{søkeord}' finnes i filen.")
            else:
                print(f"Ordet '{søkeord}' finnes ikke i filen.")

        elif valg == "2":
            print("\nInnholdet i filen:")
            printTekst(innhold)

        elif valg == "3":
            søkeord = input("Skriv ordet du vil telle: ")
            antall = tellOrd(innhold, søkeord)
            print(f"Ordet '{søkeord}' kommer {antall} ganger i filen.")

        elif valg == "4":
            break  # Går tilbake til hovedmenyen

        else:
            print("Ugyldig valg, prøv igjen.")

# Hovedprogram
def main():
    while True:
        visMeny()
        valg = input("Skriv tallet for hvilken fil du vil bruke (1-3), eller 4 for å avslutte: ")

        if valg == "1":
            utførHandlinger("tekstfil1.txt")
        elif valg == "2":
            utførHandlinger("tekstfil2.txt")
        elif valg == "3":
            utførHandlinger("tekstfil3.txt")
        elif valg == "4":
            print("Avslutter programmet.")
            break  # Avslutter programmet
        else:
            print("Ugyldig valg, prøv igjen.")

# Kjør hovedprogrammet
if __name__ == "__main__":
    main()
